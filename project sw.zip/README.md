# RequireX - AI-Powered Requirements Engineering Suite

RequireX is a full-stack, enterprise-grade AI Requirements Engineering Assistant designed for Software Engineers, Business Analysts, Project Managers, and Students. It automates the Software Requirements Engineering lifecycle using Large Language Model (LLM) intelligence, transforming raw stakeholder notes into publication-ready IEEE 830-1998 / 29148-2018 Software Requirement Specifications (SRS).

---

## 🌟 Key Features & Modules

1. **Commercial Dark Neon Interface**: Sleek Linear/Vercel/OpenAI-inspired SaaS aesthetic with `#0B0B0F` background, neon cyan/blue/purple glows, glassmorphism cards, and Framer Motion micro-animations.
2. **Module 1 & 2: Requirement Upload & Classification**: Ingest PDF, DOCX, TXT documents or interview transcripts. Classifies requirements into Functional, Non-functional, Business, System, User, and Technical categories.
3. **Module 3 & 4: IEEE Quality Audit & Standard Rewriter**: Detects ambiguity, missing actors, non-testable clauses, and missing constraints with confidence ratings. Rewrites poor requirements into formal IEEE statements (*"The system shall..."*).
4. **Module 5: Domain Missing Requirement Recommender**: Recommends domain-specific security, audit log, and performance requirements for Railway, Hospital, E-Commerce, Banking, Education, Food Delivery, and more.
5. **Module 6: Agile User Story Board**: Automatically synthesizes Agile stories (*As a... I want to... So that...*) with Fibonacci points (3, 5, 8), acceptance criteria checklists, and Definition of Done.
6. **Module 7 & 8: Textual Use Case & Acceptance Criteria Generator**: Generates primary actors, preconditions, postconditions, main success flows, alternative flows, and exception paths.
7. **Module 9: Automated Test Case Matrix**: Synthesizes Positive, Negative, Boundary, Validation, Security, and Performance test cases complete with inputs, expected outputs, priority, and status.
8. **Module 10: Risk & Volatility Radar**: Evaluates requirement volatility, project risks, complexity, and generates automated AI mitigation action strategies.
9. **Module 11: Requirement Traceability Matrix (RTM)**: Dynamic mapping between Requirements <-> Use Cases <-> Test Cases with real-time coverage meters.
10. **Module 12 & 13: IEEE SRS Generator & Multi-Format Exporter**: Live preview of full IEEE Std 830/29148 documents with one-click export to **PDF**, **Word (.docx)**, **Markdown (.md)**, and **Plain Text (.txt)**.
11. **AI Co-Pilot Assistant**: Slide-out interactive AI chatbot answering contextual project queries.
12. **Global Search (Ctrl+K) & Snapshot Version History**: Instant search index and snapshot restore timeline.

---

## 🚀 Quick Run Instructions

### Prerequisites
- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher

### Installation & Launch

1. **Clone or navigate to the project directory**:
   ```bash
   cd "PROJECT SOFTWARE ENGINEERING"
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Run Development Server**:
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your web browser.

4. **Build Production Bundle**:
   ```bash
   npm run build
   ```

---

## 📁 Directory & Folder Structure

```
PROJECT SOFTWARE ENGINEERING/
├── public/                     # Static assets & favicons
├── src/
│   ├── components/
│   │   ├── auth/              # Simple local session login & register modals
│   │   ├── chat/              # Interactive AI Co-Pilot drawer chatbot
│   │   ├── dashboard/         # Dashboard KPIs, health scores & quick actions
│   │   ├── history/           # Snapshot version control timeline
│   │   ├── landing/           # Commercial SaaS hero, features & workflow
│   │   ├── layout/            # Navbar & module navigation sidebar
│   │   ├── modules/           # RequireX Engineering Modules 1 to 13
│   │   │   ├── ModuleUpload.tsx
│   │   │   ├── ModuleQualityAudit.tsx
│   │   │   ├── ModuleDomainRecommendations.tsx
│   │   │   ├── ModuleUserStories.tsx
│   │   │   ├── ModuleUseCases.tsx
│   │   │   ├── ModuleTestCases.tsx
│   │   │   ├── ModuleRiskAnalysis.tsx
│   │   │   ├── ModuleRTM.tsx
│   │   │   ├── ModuleSRSGenerator.tsx
│   │   │   └── ModuleAnalytics.tsx
│   │   ├── projects/          # Create project modal & domain selector
│   │   └── search font/       # Global Ctrl+K search overlay
│   ├── context/               # Project state & localStorage persistence
│   ├── services/              # AI Engine & Multi-format Export Service
│   │   ├── aiEngine.ts
│   │   └── exportService.ts
│   ├── types/                 # TypeScript data contracts & IEEE schemas
│   ├── App.tsx                # Main application wrapper & module router
│   ├── main.tsx               # DOM entrypoint
│   └── index.css              # Glassmorphism tokens & neon glow CSS
├── index.html                 # HTML shell
├── package.json               # Project manifest & build scripts
├── postcss.config.js          # PostCSS setup
├── tailwind.config.js         # Dark mode & custom neon palette
├── tsconfig.json              # TypeScript configuration
├── vite.config.ts             # Vite server setup
└── README.md                  # Complete documentation
```

---

## 🛡️ License & Engineering Standard Compliance
Built according to **IEEE Std 830-1998** and **ISO/IEC/IEEE 29148-2018** Software Requirements Engineering Standards.
