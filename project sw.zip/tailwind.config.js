/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        background: '#0B0B0F',
        surface: {
          DEFAULT: '#12121A',
          hover: '#1A1A26',
          border: 'rgba(255, 255, 255, 0.08)',
          glow: 'rgba(0, 240, 255, 0.05)'
        },
        neon: {
          cyan: '#00F0FF',
          blue: '#0072FF',
          purple: '#A855F7',
          pink: '#FF0080',
          emerald: '#10B981',
          amber: '#F59E0B'
        }
      },
      fontFamily: {
        sans: ['Inter', 'Plus Jakarta Sans', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      boxShadow: {
        'neon-cyan': '0 0 20px rgba(0, 240, 255, 0.25)',
        'neon-blue': '0 0 20px rgba(0, 114, 255, 0.25)',
        'neon-purple': '0 0 20px rgba(168, 85, 247, 0.25)',
        'glass': '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'hero-gradient': 'linear-gradient(135deg, rgba(0,240,255,0.15) 0%, rgba(168,85,247,0.15) 50%, rgba(11,11,15,1) 100%)',
      },
      animation: {
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow-spin': 'spin 8s linear infinite',
      }
    },
  },
  plugins: [],
}
