import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Project, 
  Requirement, 
  UserStory, 
  UseCase, 
  TestCase, 
  RiskItem, 
  RecommendedRequirement,
  UserSession,
  VersionSnapshot
} from '../types';
import { AIEngine } from '../services/aiEngine';

type ActiveTab = 
  | 'dashboard'
  | 'upload'
  | 'quality'
  | 'recommendations'
  | 'user-stories'
  | 'use-cases'
  | 'test-cases'
  | 'risks'
  | 'rtm'
  | 'srs'
  | 'analytics';

interface ProjectContextType {
  projects: Project[];
  currentProject: Project | null;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  userSession: UserSession;
  setUserSession: React.Dispatch<React.SetStateAction<UserSession>>;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isCreateProjectOpen: boolean;
  setIsCreateProjectOpen: (open: boolean) => void;
  isAIChatOpen: boolean;
  setIsAIChatOpen: (open: boolean) => void;
  isGlobalSearchOpen: boolean;
  setIsGlobalSearchOpen: (open: boolean) => void;
  isHistoryOpen: boolean;
  setIsHistoryOpen: (open: boolean) => void;
  
  // Actions
  selectProject: (projectId: string) => void;
  createNewProject: (name: string, domain: string, description: string) => void;
  addRequirementsToProject: (reqs: Requirement[]) => void;
  updateRequirement: (updated: Requirement) => void;
  deleteRequirement: (id: string) => void;
  acceptImprovedRequirement: (id: string) => void;
  addRecommendedRequirements: (recs: RecommendedRequirement[]) => void;
  regenerateArtifacts: () => void;
  createVersionSnapshot: (description: string) => void;
  restoreVersionSnapshot: (snapshotId: string) => void;
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

const SAMPLE_RAILWAY_PROJECT: Project = {
  id: 'proj-railway-01',
  name: 'NextGen Railway Reservation System',
  domain: 'Railway Reservation',
  description: 'An AI-enhanced enterprise high-concurrency ticket booking, seat matrix, live PNR tracking, and cancellation refund platform.',
  createdAt: '2026-08-01',
  updatedAt: '2026-08-03',
  requirements: [
    {
      id: 'REQ-01',
      title: 'Fast ticket booking during peak Tatkal hours',
      description: 'The website should be fast when booking tickets during morning peak hours.',
      category: 'Non-functional',
      priority: 'Critical',
      status: 'Analyzed',
      issues: [
        {
          id: 'ISS-01',
          type: 'Ambiguous word',
          problem: 'Contains subjective phrase "website should be fast"',
          reason: 'Ambiguous speed targets cannot be validated during QA performance testing.',
          suggestedCorrection: 'Specify precise millisecond latency under quantified concurrent load.',
          confidenceScore: 95,
          severity: 'Critical'
        }
      ],
      improvedText: 'The system shall process ticket reservation requests within 1.2 seconds under a peak load of 50,000 concurrent active users.',
      isImprovedAccepted: true,
      domain: 'Railway Reservation',
      version: 1,
      createdAt: '2026-08-01'
    },
    {
      id: 'REQ-02',
      title: 'Real-time PNR Tracking & Station Alerts',
      description: 'The system shall allow passengers to query real-time PNR status and receive SMS location alerts 30 minutes before arrival.',
      category: 'Functional',
      priority: 'High',
      status: 'Approved',
      issues: [],
      improvedText: 'The system shall allow passengers to query real-time PNR status and receive SMS location alerts 30 minutes before arrival.',
      isImprovedAccepted: true,
      domain: 'Railway Reservation',
      version: 1,
      createdAt: '2026-08-01'
    },
    {
      id: 'REQ-03',
      title: 'Automated Seat Allocation Algorithm',
      description: 'The system shall allocate train berth preferences (Lower, Middle, Upper) automatically based on passenger age and vacancy matrix.',
      category: 'System',
      priority: 'Medium',
      status: 'Approved',
      issues: [],
      improvedText: 'The system shall allocate train berth preferences automatically based on passenger age and vacancy matrix.',
      isImprovedAccepted: true,
      domain: 'Railway Reservation',
      version: 1,
      createdAt: '2026-08-01'
    },
    {
      id: 'REQ-04',
      title: 'Payment Gateway Integration & Refund Processing',
      description: 'The system shall interface with external bank payment gateways and initiate ticket cancellation refunds within 24 hours.',
      category: 'Technical',
      priority: 'High',
      status: 'Approved',
      issues: [],
      improvedText: 'The system shall interface with external bank payment gateways and initiate ticket cancellation refunds within 24 hours.',
      isImprovedAccepted: true,
      domain: 'Railway Reservation',
      version: 1,
      createdAt: '2026-08-01'
    }
  ],
  recommendedRequirements: AIEngine.getDomainRecommendations('Railway Reservation'),
  userStories: [],
  useCases: [],
  testCases: [],
  risks: [],
  history: []
};

// Initialize initial artifacts for sample project
SAMPLE_RAILWAY_PROJECT.userStories = AIEngine.generateUserStories(SAMPLE_RAILWAY_PROJECT.requirements);
SAMPLE_RAILWAY_PROJECT.useCases = AIEngine.generateUseCases(SAMPLE_RAILWAY_PROJECT.requirements);
SAMPLE_RAILWAY_PROJECT.testCases = AIEngine.generateTestCases(SAMPLE_RAILWAY_PROJECT.requirements);
SAMPLE_RAILWAY_PROJECT.risks = AIEngine.generateRisks(SAMPLE_RAILWAY_PROJECT.requirements);

export const ProjectProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem('requirex_projects');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return [SAMPLE_RAILWAY_PROJECT];
  });

  const [currentProjectId, setCurrentProjectId] = useState<string>(() => projects[0]?.id || 'proj-railway-01');
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  
  const [userSession, setUserSession] = useState<UserSession>(() => {
    const savedUser = localStorage.getItem('requirex_user');
    if (savedUser) {
      try { return JSON.parse(savedUser); } catch (e) { console.error(e); }
    }
    return {
      username: 'Engineering Lead',
      email: 'lead@enterprise.io',
      role: 'Senior Business Analyst',
      isLoggedIn: true
    };
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isCreateProjectOpen, setIsCreateProjectOpen] = useState<boolean>(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState<boolean>(false);
  const [isGlobalSearchOpen, setIsGlobalSearchOpen] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('requirex_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('requirex_user', JSON.stringify(userSession));
  }, [userSession]);

  const currentProject = projects.find(p => p.id === currentProjectId) || projects[0] || null;

  const selectProject = (id: string) => {
    setCurrentProjectId(id);
  };

  const createNewProject = (name: string, domain: string, description: string) => {
    const recommendations = AIEngine.getDomainRecommendations(domain);
    const newProj: Project = {
      id: `proj-${Math.random().toString(36).substring(2, 9)}`,
      name,
      domain,
      description,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      requirements: [],
      recommendedRequirements: recommendations,
      userStories: [],
      useCases: [],
      testCases: [],
      risks: [],
      history: []
    };

    setProjects(prev => [newProj, ...prev]);
    setCurrentProjectId(newProj.id);
    setActiveTab('upload');
    setIsCreateProjectOpen(false);
  };

  const updateProjectState = (updater: (proj: Project) => Project) => {
    setProjects(prev => prev.map(p => {
      if (p.id === currentProjectId) {
        const updated = updater(p);
        updated.updatedAt = new Date().toISOString().split('T')[0];
        return updated;
      }
      return p;
    }));
  };

  const addRequirementsToProject = (newReqs: Requirement[]) => {
    updateProjectState(proj => {
      const combined = [...proj.requirements, ...newReqs];
      return {
        ...proj,
        requirements: combined,
        userStories: AIEngine.generateUserStories(combined),
        useCases: AIEngine.generateUseCases(combined),
        testCases: AIEngine.generateTestCases(combined),
        risks: AIEngine.generateRisks(combined)
      };
    });
  };

  const updateRequirement = (updated: Requirement) => {
    updateProjectState(proj => {
      const reqs = proj.requirements.map(r => r.id === updated.id ? updated : r);
      return {
        ...proj,
        requirements: reqs,
        userStories: AIEngine.generateUserStories(reqs),
        useCases: AIEngine.generateUseCases(reqs),
        testCases: AIEngine.generateTestCases(reqs)
      };
    });
  };

  const deleteRequirement = (id: string) => {
    updateProjectState(proj => {
      const reqs = proj.requirements.filter(r => r.id !== id);
      return {
        ...proj,
        requirements: reqs,
        userStories: AIEngine.generateUserStories(reqs),
        useCases: AIEngine.generateUseCases(reqs),
        testCases: AIEngine.generateTestCases(reqs)
      };
    });
  };

  const acceptImprovedRequirement = (id: string) => {
    updateProjectState(proj => {
      const reqs = proj.requirements.map(r => {
        if (r.id === id && r.improvedText) {
          return {
            ...r,
            description: r.improvedText,
            issues: [],
            status: 'Approved' as const,
            isImprovedAccepted: true
          };
        }
        return r;
      });

      return {
        ...proj,
        requirements: reqs,
        userStories: AIEngine.generateUserStories(reqs),
        useCases: AIEngine.generateUseCases(reqs),
        testCases: AIEngine.generateTestCases(reqs)
      };
    });
  };

  const addRecommendedRequirements = (selectedRecs: RecommendedRequirement[]) => {
    const convertedReqs: Requirement[] = selectedRecs.map((rec, i) => ({
      id: `REQ-${String((currentProject?.requirements.length || 0) + i + 1).padStart(2, '0')}`,
      title: rec.title,
      description: rec.description,
      category: rec.category,
      priority: 'High',
      status: 'Approved',
      issues: [],
      improvedText: rec.description,
      isImprovedAccepted: true,
      domain: rec.domain,
      version: 1,
      createdAt: new Date().toISOString().split('T')[0]
    }));

    addRequirementsToProject(convertedReqs);
  };

  const regenerateArtifacts = () => {
    if (!currentProject) return;
    updateProjectState(proj => ({
      ...proj,
      userStories: AIEngine.generateUserStories(proj.requirements),
      useCases: AIEngine.generateUseCases(proj.requirements),
      testCases: AIEngine.generateTestCases(proj.requirements),
      risks: AIEngine.generateRisks(proj.requirements)
    }));
  };

  const createVersionSnapshot = (description: string) => {
    if (!currentProject) return;
    const nextVer = (currentProject.history.length || 0) + 1;
    const snapshot: VersionSnapshot = {
      id: `snap-${Date.now()}`,
      versionNumber: nextVer,
      timestamp: new Date().toLocaleString(),
      description,
      requirements: [...currentProject.requirements],
      userStories: [...currentProject.userStories],
      useCases: [...currentProject.useCases],
      testCases: [...currentProject.testCases],
      risks: [...currentProject.risks]
    };

    updateProjectState(proj => ({
      ...proj,
      history: [snapshot, ...proj.history]
    }));
  };

  const restoreVersionSnapshot = (snapshotId: string) => {
    if (!currentProject) return;
    const target = currentProject.history.find(h => h.id === snapshotId);
    if (!target) return;

    updateProjectState(proj => ({
      ...proj,
      requirements: [...target.requirements],
      userStories: [...target.userStories],
      useCases: [...target.useCases],
      testCases: [...target.testCases],
      risks: [...target.risks]
    }));
  };

  return (
    <ProjectContext.Provider
      value={{
        projects,
        currentProject,
        activeTab,
        setActiveTab,
        userSession,
        setUserSession,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isCreateProjectOpen,
        setIsCreateProjectOpen,
        isAIChatOpen,
        setIsAIChatOpen,
        isGlobalSearchOpen,
        setIsGlobalSearchOpen,
        isHistoryOpen,
        setIsHistoryOpen,
        selectProject,
        createNewProject,
        addRequirementsToProject,
        updateRequirement,
        deleteRequirement,
        acceptImprovedRequirement,
        addRecommendedRequirements,
        regenerateArtifacts,
        createVersionSnapshot,
        restoreVersionSnapshot
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
};

export const useProject = () => {
  const context = useContext(ProjectContext);
  if (!context) {
    throw new Error('useProject must be used within a ProjectProvider');
  }
  return context;
};
