export type RequirementCategory = 
  | 'Functional' 
  | 'Non-functional' 
  | 'Business' 
  | 'System' 
  | 'User' 
  | 'Technical';

export type PriorityLevel = 'High' | 'Medium' | 'Low' | 'Critical';
export type SeverityLevel = 'High' | 'Medium' | 'Low' | 'Critical';
export type IssueType = 
  | 'Ambiguous word' 
  | 'Incomplete statement' 
  | 'Weak requirement' 
  | 'Duplicate requirement' 
  | 'Conflicting requirement' 
  | 'Non-testable requirement' 
  | 'Missing constraint' 
  | 'Missing actor' 
  | 'Missing assumption';

export interface QualityIssue {
  id: string;
  type: IssueType;
  problem: string;
  reason: string;
  suggestedCorrection: string;
  confidenceScore: number;
  severity: SeverityLevel;
}

export interface Requirement {
  id: string;
  title: string;
  description: string;
  category: RequirementCategory;
  priority: PriorityLevel;
  status: 'Draft' | 'Analyzed' | 'Improved' | 'Approved';
  issues: QualityIssue[];
  improvedText?: string;
  isImprovedAccepted?: boolean;
  domain: string;
  version: number;
  createdAt: string;
}

export interface RecommendedRequirement {
  id: string;
  category: RequirementCategory;
  title: string;
  description: string;
  domain: string;
  selected: boolean;
}

export interface UserStory {
  id: string;
  requirementId?: string;
  asA: string;
  iWantTo: string;
  soThat: string;
  priority: PriorityLevel;
  storyPoints: number;
  acceptanceCriteria: string[];
  definitionOfDone: string[];
  gherkinScenario?: string;
}

export interface UseCase {
  id: string;
  requirementId?: string;
  title: string;
  actors: string[];
  preconditions: string[];
  postconditions: string[];
  mainFlow: string[];
  alternativeFlow: string[];
  exceptions: string[];
  relationships: string[];
}

export interface TestCase {
  id: string;
  requirementId: string;
  category: 'Positive' | 'Negative' | 'Boundary' | 'Validation' | 'Security' | 'Performance';
  description: string;
  inputData: string;
  expectedOutput: string;
  priority: PriorityLevel;
  status: 'Passed' | 'Pending' | 'Failed' | 'Draft';
}

export interface RiskItem {
  id: string;
  title: string;
  category: 'Requirement Risk' | 'Project Risk' | 'Requirement Volatility' | 'Complexity' | 'Dependency Issue';
  impact: 'High' | 'Medium' | 'Low';
  probability: 'High' | 'Medium' | 'Low';
  mitigation: string;
  affectedRequirementIds: string[];
}

export interface RTMRow {
  requirementId: string;
  requirementTitle: string;
  category: RequirementCategory;
  useCaseId: string;
  testCaseIds: string[];
  status: 'Covered' | 'Partial' | 'Uncovered';
  priority: PriorityLevel;
}

export interface ComplianceCheck {
  id: string;
  criterion: string;
  description: string;
  score: number; // 0 - 100
  status: 'Passed' | 'Warning' | 'Failed';
  recommendation: string;
}

export interface VersionSnapshot {
  id: string;
  versionNumber: number;
  timestamp: string;
  description: string;
  requirements: Requirement[];
  userStories: UserStory[];
  useCases: UseCase[];
  testCases: TestCase[];
  risks: RiskItem[];
}

export interface Project {
  id: string;
  name: string;
  domain: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  requirements: Requirement[];
  recommendedRequirements: RecommendedRequirement[];
  userStories: UserStory[];
  useCases: UseCase[];
  testCases: TestCase[];
  risks: RiskItem[];
  complianceChecks?: ComplianceCheck[];
  history: VersionSnapshot[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  actionButtons?: { label: string; tabTarget: string }[];
}

export interface UserSession {
  username: string;
  email: string;
  role: string;
  isLoggedIn: boolean;
}
