import { 
  Requirement, 
  RequirementCategory, 
  QualityIssue, 
  RecommendedRequirement, 
  UserStory, 
  UseCase, 
  TestCase, 
  RiskItem, 
  RTMRow,
  ComplianceCheck,
  PriorityLevel
} from '../types';

export const DOMAIN_RECOMMENDATIONS: Record<string, Omit<RecommendedRequirement, 'id' | 'selected'>[]> = {
  'Online Quiz Platform': [
    { category: 'Functional', title: 'Automated Quiz Evaluation & Real-time Scoreboard', description: 'The system shall evaluate student quiz submissions automatically upon timer expiration and compute percentile rank.', domain: 'Online Quiz Platform' },
    { category: 'Functional', title: 'Randomized Question Bank & Shuffling', description: 'The system shall draw questions dynamically from a tagged repository and shuffle answer option sequences per candidate.', domain: 'Online Quiz Platform' },
    { category: 'Non-functional', title: 'Anti-Cheating Proctoring & Tab-Switch Detection', description: 'The system shall monitor candidate browser focus, detect tab-switching events, and auto-submit after 3 warnings.', domain: 'Online Quiz Platform' },
    { category: 'Technical', title: 'High-Concurrency Exam Submission Sync', description: 'The system shall buffer exam answers locally in IndexedDB and sync to cloud server with zero data loss on network drops.', domain: 'Online Quiz Platform' },
    { category: 'System', title: 'Instructor Assessment Analytics & Item Analysis', description: 'The system shall provide instructors question difficulty indices, discrimination ratings, and bell-curve reports.', domain: 'Online Quiz Platform' }
  ],
  'Railway Reservation': [
    { category: 'Functional', title: 'PNR Status Tracking & Real-Time Inquiry', description: 'The system shall allow users to query real-time PNR booking status and train location updates.', domain: 'Railway Reservation' },
    { category: 'Functional', title: 'Seat Availability & Automated Allocation', description: 'The system shall calculate seat matrix and automatically allocate berth classes based on passenger preference.', domain: 'Railway Reservation' },
    { category: 'Functional', title: 'Refund & Cancellation Management', description: 'The system shall process automated ticket cancellations and calculate refund breakdown according to railway rules.', domain: 'Railway Reservation' },
    { category: 'Non-functional', title: 'Tatkal Booking Peak Concurrency Handling', description: 'The system shall sustain 50,000 concurrent ticket booking requests per minute during opening hours without degradation.', domain: 'Railway Reservation' },
    { category: 'Technical', title: 'Payment Gateway Failover & Webhook Sync', description: 'The system shall integrate multi-bank payment gateways with automatic 30-second failover and instant refund webhooks.', domain: 'Railway Reservation' }
  ],
  'Hospital Management': [
    { category: 'Functional', title: 'Patient Electronic Health Record (EHR)', description: 'The system shall maintain centralized patient medical histories, lab reports, and prescription records.', domain: 'Hospital Management' },
    { category: 'Functional', title: 'Doctor Appointment Scheduling & Queue Management', description: 'The system shall schedule outpatient visits and display real-time waiting room token numbers.', domain: 'Hospital Management' },
    { category: 'Non-functional', title: 'HIPAA & Data Privacy Compliance', description: 'The system shall encrypt all patient protected health information (PHI) at rest using AES-256 encryption.', domain: 'Hospital Management' }
  ],
  'E-Commerce': [
    { category: 'Functional', title: 'Smart Search & Faceted Product Filtering', description: 'The system shall enable fuzzy search and multi-attribute filtering by price, brand, rating, and category.', domain: 'E-Commerce' },
    { category: 'Functional', title: 'Shopping Cart & Multi-Currency Checkout', description: 'The system shall calculate item subtotal, taxes, shipping discounts, and convert currency dynamically.', domain: 'E-Commerce' }
  ],
  'Banking': [
    { category: 'Functional', title: 'Fund Transfer & Real-time Settlement (IMPS/NEFT)', description: 'The system shall execute interbank money transfers with instant validation and dual-authorization limits.', domain: 'Banking' }
  ]
};

const DEFAULT_DOMAIN_RECOMMENDATIONS: Omit<RecommendedRequirement, 'id' | 'selected'>[] = [
  { category: 'Functional', title: 'User Authentication & Multi-Factor Security', description: 'The system shall support OAuth 2.0, biometric login, and mandatory MFA for administrative privileges.', domain: 'General' },
  { category: 'Non-functional', title: 'System Auditing & Comprehensive Trace Logs', description: 'The system shall record all user actions, timestamp changes, and IP addresses in an append-only audit trail.', domain: 'General' },
  { category: 'Non-functional', title: 'Data Backup & Disaster Recovery RPO/RTO', description: 'The system shall execute automated daily database backups with RPO < 1 hour and RTO < 4 hours.', domain: 'General' }
];

export class AIEngine {
  static extractRequirements(rawText: string, domain: string): Requirement[] {
    if (!rawText.trim()) return [];

    const lines = rawText
      .split(/\n+|\d+\.\s+|•|-|;/)
      .map(l => l.trim())
      .filter(l => l.length > 8);

    const requirements: Requirement[] = [];

    lines.forEach((line, index) => {
      const lower = line.toLowerCase();
      let category: RequirementCategory = 'Functional';
      let priority: PriorityLevel = 'Medium';

      if (lower.includes('speed') || lower.includes('fast') || lower.includes('performance') || lower.includes('secure') || lower.includes('encrypt') || lower.includes('uptime') || lower.includes('scale') || lower.includes('proctor') || lower.includes('cheat')) {
        category = 'Non-functional';
      } else if (lower.includes('business') || lower.includes('revenue') || lower.includes('compliance') || lower.includes('policy')) {
        category = 'Business';
      } else if (lower.includes('admin') || lower.includes('dashboard') || lower.includes('instructor') || lower.includes('system shall')) {
        category = 'System';
      } else if (lower.includes('user') || lower.includes('student') || lower.includes('candidate') || lower.includes('as a')) {
        category = 'User';
      } else if (lower.includes('api') || lower.includes('database') || lower.includes('integration') || lower.includes('indexeddb') || lower.includes('sync')) {
        category = 'Technical';
      }

      if (lower.includes('must') || lower.includes('critical') || lower.includes('urgent') || lower.includes('security')) {
        priority = 'High';
      }

      const issues = AIEngine.analyzeQuality(line);

      requirements.push({
        id: `REQ-${String(index + 1).padStart(2, '0')}`,
        title: line.length > 50 ? line.substring(0, 47) + '...' : line,
        description: line,
        category,
        priority,
        status: issues.length > 0 ? 'Analyzed' : 'Draft',
        issues,
        improvedText: AIEngine.generateIEEEText(line),
        isImprovedAccepted: false,
        domain,
        version: 1,
        createdAt: new Date().toISOString().split('T')[0]
      });
    });

    return requirements;
  }

  static analyzeQuality(text: string): QualityIssue[] {
    const issues: QualityIssue[] = [];
    const lower = text.toLowerCase();

    const ambiguousWords = ['fast', 'user-friendly', 'easy', 'robust', 'quick', 'efficient', 'seamless', 'good', 'appropriate'];
    const foundAmbiguous = ambiguousWords.filter(w => lower.includes(w));
    if (foundAmbiguous.length > 0) {
      issues.push({
        id: `ISS-${Math.random().toString(36).substring(2, 7)}`,
        type: 'Ambiguous word',
        problem: `Contains subjective term(s): "${foundAmbiguous.join(', ')}"`,
        reason: 'Subjective terms lead to differing interpretations between clients and developers.',
        suggestedCorrection: `Replace "${foundAmbiguous[0]}" with explicit measurable metrics (e.g. "within 1.5 seconds" or "evaluated within 500ms").`,
        confidenceScore: 95,
        severity: 'High'
      });
    }

    if (!lower.includes('system') && !lower.includes('user') && !lower.includes('student') && !lower.includes('instructor') && !lower.includes('admin') && !lower.includes('candidate')) {
      issues.push({
        id: `ISS-${Math.random().toString(36).substring(2, 7)}`,
        type: 'Missing actor',
        problem: 'No explicit subject/actor defined.',
        reason: 'It is unclear who or what component is responsible for executing this behavior.',
        suggestedCorrection: 'Specify the primary subject (e.g., "The system shall...", "The candidate shall...").',
        confidenceScore: 88,
        severity: 'Medium'
      });
    }

    return issues;
  }

  static generateIEEEText(raw: string): string {
    let cleaned = raw.trim();

    if (cleaned.toLowerCase().includes('should be fast')) {
      return 'The system shall process user requests within 1.2 seconds under peak concurrency load.';
    }
    if (cleaned.toLowerCase().includes('prevent cheating') || cleaned.toLowerCase().includes('proctor')) {
      return 'The system shall monitor candidate browser focus, log window blur events, and auto-submit the exam upon 3 unauthorized tab switches.';
    }

    cleaned = cleaned.replace(/^(should|must|website should|system needs to|we need|please make sure)/i, '');
    cleaned = cleaned.charAt(0).toLowerCase() + cleaned.slice(1);

    if (!cleaned.toLowerCase().startsWith('the system shall') && !cleaned.toLowerCase().startsWith('the user shall')) {
      return `The system shall ${cleaned.replace(/^to\s+/i, '')}.`;
    }

    return cleaned;
  }

  static getDomainRecommendations(domain: string): RecommendedRequirement[] {
    const specific = DOMAIN_RECOMMENDATIONS[domain] || [];
    const combined = [...specific, ...DEFAULT_DOMAIN_RECOMMENDATIONS];

    return combined.map((rec, i) => ({
      id: `REC-${domain.substring(0, 3).toUpperCase()}-${i + 1}`,
      ...rec,
      selected: false
    }));
  }

  static generateUserStories(requirements: Requirement[]): UserStory[] {
    return requirements.map((req, idx) => {
      const titleLower = req.title.toLowerCase();
      let role = 'Software User';
      let action = req.title;
      let benefit = 'improve operational efficiency and system safety';

      if (titleLower.includes('quiz') || titleLower.includes('exam') || titleLower.includes('student') || titleLower.includes('score')) {
        role = 'Student Candidate';
        action = 'take timed online quizzes with instant automated scoring';
        benefit = 'view performance analytics and review answer explanations immediately';
      } else if (titleLower.includes('instructor') || titleLower.includes('question') || titleLower.includes('teacher')) {
        role = 'Course Instructor';
        action = 'create randomized question banks and schedule proctored exams';
        benefit = 'evaluate student learning outcomes accurately without manual grading';
      } else if (titleLower.includes('pnr') || titleLower.includes('ticket') || titleLower.includes('booking')) {
        role = 'Passenger';
        action = 'search seat availability and reserve tickets online';
        benefit = 'plan travel itineraries seamlessly';
      }

      const gherkin = `Feature: ${req.title}
  Scenario: Nominal execution of ${req.id}
    Given the user is authenticated on the platform
    When valid inputs are provided for "${req.title}"
    Then the system processes request in < 1.5s
    And an audit event is logged with status 200 OK`;

      return {
        id: `US-${String(idx + 1).padStart(2, '0')}`,
        requirementId: req.id,
        asA: role,
        iWantTo: action,
        soThat: benefit,
        priority: req.priority,
        storyPoints: req.priority === 'High' ? 8 : req.priority === 'Medium' ? 5 : 3,
        acceptanceCriteria: [
          `Given candidate starts the quiz, when timer expires, then exam auto-submits.`,
          `Given internet disconnection, when reconnected, local draft answers sync without loss.`,
          `Given quiz completion, an itemized scorecard report is generated.`
        ],
        definitionOfDone: [
          'Code written, peer reviewed & merged',
          'Unit test suite passed with > 85% coverage',
          'QA manual testing verified',
          'Documentation updated'
        ],
        gherkinScenario: gherkin
      };
    });
  }

  static generateUseCases(requirements: Requirement[]): UseCase[] {
    return requirements.map((req, idx) => ({
      id: `UC-${String(idx + 1).padStart(2, '0')}`,
      requirementId: req.id,
      title: `Execute ${req.title}`,
      actors: [getActorForRequirement(req), 'System Processing Kernel'],
      preconditions: [
        'User is authenticated with active session token',
        'System state is online and operational'
      ],
      postconditions: [
        'Transaction committed to database',
        'Audit trail log generated'
      ],
      mainFlow: [
        '1. User initiates feature action from dashboard.',
        '2. System displays input parameters form.',
        '3. User submits data payload.',
        '4. System validates parameters and executes core business logic.',
        '5. System returns 200 OK and renders confirmation UI.'
      ],
      alternativeFlow: [
        '3a. User requests draft save: System caches state in session store.'
      ],
      exceptions: [
        '4a. Validation error or connection failure: System rolls back transaction, displays error banner E-400.'
      ],
      relationships: ['Includes: Authentication Service', 'Extends: Audit Logger']
    }));
  }

  static generateTestCases(requirements: Requirement[]): TestCase[] {
    const testCases: TestCase[] = [];
    let testIdx = 1;

    requirements.forEach((req) => {
      testCases.push({
        id: `TC-${String(testIdx++).padStart(3, '0')}`,
        requirementId: req.id,
        category: 'Positive',
        description: `Verify standard nominal execution of ${req.title}.`,
        inputData: 'Valid JSON payload matching schema standards',
        expectedOutput: 'HTTP 200 OK / Success UI rendered',
        priority: req.priority,
        status: 'Passed'
      });

      testCases.push({
        id: `TC-${String(testIdx++).padStart(3, '0')}`,
        requirementId: req.id,
        category: 'Negative',
        description: `Verify system validation when null or malformed data is passed to ${req.title}.`,
        inputData: 'Malformed payload / Null attributes',
        expectedOutput: 'HTTP 400 Bad Request with field validation errors',
        priority: req.priority,
        status: 'Passed'
      });

      testCases.push({
        id: `TC-${String(testIdx++).padStart(3, '0')}`,
        requirementId: req.id,
        category: 'Security',
        description: `Verify SQL Injection & XSS sanitization during submission of ${req.title}.`,
        inputData: "' OR '1'='1; <script>alert('xss')</script>",
        expectedOutput: 'Input sanitized, payload blocked by WAF filter',
        priority: 'High',
        status: 'Passed'
      });

      testCases.push({
        id: `TC-${String(testIdx++).padStart(3, '0')}`,
        requirementId: req.id,
        category: 'Performance',
        description: `Verify response latency under concurrent traffic for ${req.title}.`,
        inputData: '1,000 concurrent active session requests',
        expectedOutput: 'Response time <= 1.5s, 0% request drop rate',
        priority: 'Medium',
        status: 'Pending'
      });
    });

    return testCases;
  }

  static generateRisks(requirements: Requirement[]): RiskItem[] {
    return [
      {
        id: 'RSK-01',
        title: 'Requirement Volatility & Unclear SLAs',
        category: 'Requirement Volatility',
        impact: 'High',
        probability: 'Medium',
        mitigation: 'Implement formal IEEE change control sign-off and version snapshot tagging.',
        affectedRequirementIds: requirements.slice(0, 2).map(r => r.id)
      },
      {
        id: 'RSK-02',
        title: 'Third-Party Integration Throttling & Latency',
        category: 'Dependency Issue',
        impact: 'High',
        probability: 'High',
        mitigation: 'Implement circuit breaker pattern, localized caching, and background sync queues.',
        affectedRequirementIds: requirements.filter(r => r.category === 'Technical').map(r => r.id)
      }
    ];
  }

  static generateRTM(requirements: Requirement[], useCases: UseCase[], testCases: TestCase[]): RTMRow[] {
    return requirements.map(req => {
      const matchingUseCase = useCases.find(uc => uc.requirementId === req.id);
      const matchingTestCases = testCases.filter(tc => tc.requirementId === req.id).map(tc => tc.id);

      return {
        requirementId: req.id,
        requirementTitle: req.title,
        category: req.category,
        useCaseId: matchingUseCase ? matchingUseCase.id : 'N/A',
        testCaseIds: matchingTestCases,
        status: (matchingUseCase && matchingTestCases.length > 0) ? 'Covered' : 'Partial',
        priority: req.priority
      };
    });
  }

  static generateComplianceChecks(requirements: Requirement[]): ComplianceCheck[] {
    const total = requirements.length;
    const ambiguousCount = requirements.filter(r => r.issues.some(i => i.type === 'Ambiguous word')).length;
    const missingActorCount = requirements.filter(r => r.issues.some(i => i.type === 'Missing actor')).length;

    return [
      { id: 'CMP-01', criterion: 'Completeness', description: 'All core sub-modules, constraints, and exceptions defined.', score: 92, status: 'Passed', recommendation: 'Specification covers core functional paths.' },
      { id: 'CMP-02', criterion: 'Unambiguity', description: 'Requirements have single, clear interpretation without subjective words.', score: total > 0 ? Math.round(((total - ambiguousCount) / total) * 100) : 100, status: ambiguousCount === 0 ? 'Passed' : 'Warning', recommendation: ambiguousCount > 0 ? `Rewrite ${ambiguousCount} flagged ambiguous statement(s) into IEEE format.` : 'Passed IEEE quality audit.' },
      { id: 'CMP-03', criterion: 'Verifiability / Testability', description: 'Acceptance criteria exist and QA engineers can write pass/fail unit tests.', score: 95, status: 'Passed', recommendation: 'Test case matrix generated across 6 categories.' },
      { id: 'CMP-04', criterion: 'Traceability', description: 'Bi-directional mapping between requirements, use cases, and test cases.', score: 96, status: 'Passed', recommendation: 'Requirement Traceability Matrix (RTM) active.' },
      { id: 'CMP-05', criterion: 'Modifiability & Versioning', description: 'Structure allows clean updates without conflicting requirements.', score: 90, status: 'Passed', recommendation: 'Version snapshot engine active.' },
      { id: 'CMP-06', criterion: 'Correctness & Feasibility', description: 'Requirements align with technology stack and domain boundaries.', score: 94, status: 'Passed', recommendation: 'Domain rules validated.' }
    ];
  }

  /**
   * Enhanced Dynamic AI Co-Pilot Assistant Logic
   */
  static getAIChatResponse(query: string, requirements: Requirement[], domain: string): string {
    const q = query.toLowerCase();
    const reqCount = requirements.length;
    const funcCount = requirements.filter(r => r.category === 'Functional').length;
    const nonFuncCount = requirements.filter(r => r.category !== 'Functional').length;
    const ambiguousCount = requirements.filter(r => r.issues.some(i => i.type === 'Ambiguous word')).length;

    if (q.includes('missing') || q.includes('recommend') || q.includes('suggest')) {
      return `### 💡 Recommended Features for **${domain}**

Based on AI domain knowledge analysis for **${domain}**, here are essential missing requirements you should add:

1. **Anti-Cheating & Proctoring**: Browser window focus tracking, tab-switch detection, and automatic exam termination after 3 warnings.
2. **Offline Buffer & Auto-Sync**: Client-side IndexedDB answer buffering to ensure 0% data loss during unexpected network drops.
3. **Question Bank Shuffling & Item Analysis**: Randomized question sequence per candidate and instructor difficulty bell-curve metrics.
4. **Audit Logging & MFA**: Multi-factor authentication for administrative actions and SHA-256 signed audit trails.

👉 *You can select and import these in 1-click inside **Domain Suggestions (Module 5)**!*`;
    }

    if (q.includes('quality') || q.includes('ambigu') || q.includes('audit') || q.includes('score')) {
      const healthScore = reqCount > 0 ? Math.round(((reqCount - ambiguousCount) / reqCount) * 100) : 100;
      return `### 🛡️ IEEE 830 Quality Audit Summary

- **Total Analyzed Requirements**: \`${reqCount}\`
- **Ambiguous Statements Flagged**: \`${ambiguousCount}\`
- **Quality Health Index**: \`${healthScore}%\`

${ambiguousCount > 0 
  ? `⚠️ **Action Needed**: ${ambiguousCount} requirement(s) contain subjective terms like *"fast"* or *"user-friendly"*. Navigate to **IEEE Quality Audit (Module 3 & 4)** to accept automatic IEEE rewrites (*"The system shall..."*)!` 
  : `✅ **Great job!** All current requirements pass IEEE 830 quality standards without ambiguity defects.`}`;
    }

    if (q.includes('story') || q.includes('agile') || q.includes('user story')) {
      return `### 📖 Agile User Story Breakdown

Your project currently has **${reqCount} Agile User Stories** synthesized from your specifications.

Each story contains:
- **Triple Format**: *As a [User/Student/Passenger]... I want to... So that...*
- **Fibonacci Points**: Estimated complexity points (3, 5, 8 pts).
- **Gherkin Scenarios**: Executable \`Given ... When ... Then ...\` acceptance rules.
- **Definition of Done (DoD)**: Code review, unit test coverage, and QA sign-off checklists.

👉 *View your complete story board in **Agile User Stories (Module 6)**!*`;
    }

    if (q.includes('test') || q.includes('qa') || q.includes('matrix')) {
      return `### 🧪 QA Test Suite Summary

RequireX has compiled **${reqCount * 4} Automated Test Cases** for your project across 6 core quality categories:
- **Positive & Functional Tests**: Nominal valid payloads.
- **Negative Tests**: Malformed data & HTTP 400 validation error handling.
- **Security Tests**: SQL Injection, XSS sanitization & WAF rules.
- **Performance & Load Tests**: Concurrent user latency benchmarks.

👉 *Inspect the full interactive matrix in **Test Case Matrix (Module 9)**!*`;
    }

    if (q.includes('srs') || q.includes('export') || q.includes('pdf') || q.includes('docx')) {
      return `### 📄 IEEE SRS Document Exporter

Your Software Requirement Specification for **${domain}** is complete and fully formatted to **IEEE Std 830-1998 / 29148-2018** standards.

You can export the publication-ready document right now in:
1. **PDF Document** (formatted with title page & standard headers)
2. **Word Document (.docx)**
3. **Markdown (.md)**
4. **Plain Text (.txt)**

👉 *Navigate to **IEEE SRS & Export (Module 12 & 13)** to download!*`;
    }

    if (q.includes('risk') || q.includes('volatility') || q.includes('creep')) {
      return `### ⚠️ Risk & Volatility Analysis

RequireX identified key risks in **${domain}**:
1. **High Concurrency Peak Load**: Risk of latency drops during peak submission windows. *Mitigation: Async queue buffering.*
2. **Scope Creep**: Risk of changing stakeholder requirements. *Mitigation: IEEE version snapshot tagging.*

👉 *Inspect full mitigations in **Risk Analysis (Module 10)**!*`;
    }

    // Default intelligent contextual response
    return `### 🤖 RequireX AI Co-Pilot Summary for **${domain}**

- **Project Name**: \`${domain}\`
- **Total Requirements**: \`${reqCount}\` (${funcCount} Functional, ${nonFuncCount} Non-Functional)
- **Quality Ambiguities**: \`${ambiguousCount} flagged\`

I can help you:
- Recommend missing security or proctoring features
- Analyze requirement ambiguity and generate IEEE rewrites
- Synthesize Agile User Stories and Gherkin BDD test scenarios
- Export complete IEEE SRS documents to PDF or Word

What specific area would you like to explore?`;
  }
}

function getActorForRequirement(req: Requirement): string {
  const t = req.title.toLowerCase();
  if (t.includes('quiz') || t.includes('student') || t.includes('exam')) return 'Student / Candidate';
  if (t.includes('instructor') || t.includes('teacher')) return 'Course Instructor';
  if (t.includes('patient')) return 'Patient / Medical Staff';
  if (t.includes('passenger') || t.includes('pnr')) return 'Railway Passenger';
  if (t.includes('admin')) return 'System Administrator';
  return 'Primary System User';
}
