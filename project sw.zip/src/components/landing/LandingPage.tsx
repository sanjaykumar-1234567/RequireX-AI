import React from 'react';
import { 
  Boxes, 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  FileSpreadsheet, 
  Zap, 
  GitBranch, 
  CheckCircle2, 
  Layers, 
  Lock, 
  Cpu, 
  Terminal,
  FileCheck,
  TrendingUp
} from 'lucide-react';

export const LandingPage: React.FC<{ onGetStarted: () => void }> = ({ onGetStarted }) => {
  return (
    <div className="relative overflow-hidden bg-[#0B0B0F]">
      {/* Hero Glow Background Elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-gradient-to-tr from-cyan-500/15 via-purple-500/10 to-transparent blur-3xl pointer-events-none rounded-full" />
      <div className="absolute top-1/4 right-0 w-[400px] h-[400px] bg-blue-600/10 blur-3xl pointer-events-none rounded-full" />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-semibold mb-6">
          <Sparkles className="h-3.5 w-3.5" />
          <span>IEEE 830-1998 & 29148-2018 Standardized AI Engine</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-tight font-sans">
          Automate Requirements Engineering with <span className="neon-text-gradient">Next-Gen AI</span>
        </h1>

        <p className="mt-6 text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto font-light leading-relaxed">
          Convert raw client notes, stakeholder transcripts, and unstructured documents into production-grade Software Requirement Specifications, Agile User Stories, Textual Use Cases, and Automated Test Suites.
        </p>

        {/* CTA Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onGetStarted}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-black font-bold text-sm shadow-neon-cyan transition duration-300 flex items-center justify-center space-x-2 group"
          >
            <span>Get Started Free</span>
            <ArrowRight className="h-4 w-4 text-black group-hover:translate-x-1 transition duration-200" />
          </button>
          
          <a
            href="#workflow"
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-surface hover:bg-surface-hover text-slate-200 border border-white/10 text-sm font-semibold transition duration-200 flex items-center justify-center space-x-2"
          >
            <span>Explore Workflow</span>
          </a>
        </div>

        {/* Live Interactive Preview Card Mockup */}
        <div className="mt-16 max-w-5xl mx-auto rounded-2xl p-1 bg-gradient-to-b from-white/15 to-transparent shadow-2xl">
          <div className="rounded-[15px] bg-[#12121A] p-4 sm:p-6 border border-white/10 text-left font-mono text-xs">
            <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
              <div className="flex items-center space-x-2">
                <div className="h-3 w-3 rounded-full bg-red-500/80" />
                <div className="h-3 w-3 rounded-full bg-amber-500/80" />
                <div className="h-3 w-3 rounded-full bg-emerald-500/80" />
                <span className="text-slate-400 pl-2 text-[11px]">RequireX AI Kernel v1.0 • Railway_Reservation_IEEE.srs</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-sans font-bold">QUALITY SCORE: 98%</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-black/50 p-4 rounded-xl border border-red-500/30">
                <span className="text-red-400 font-bold font-sans text-xs">INPUT (RAW UNSTRUCTURED REQUIREMENT):</span>
                <p className="text-slate-300 mt-2 text-xs font-sans">"The website should be fast when passengers try to book Tatkal tickets in the morning."</p>
                <div className="mt-3 flex items-center space-x-2 text-[10px] text-amber-400 font-sans">
                  <ShieldCheck className="h-3.5 w-3.5" />
                  <span>Flagged: 2 Ambiguities (Subjective phrase "should be fast", missing operational context)</span>
                </div>
              </div>

              <div className="bg-black/50 p-4 rounded-xl border border-cyan-500/40 shadow-neon-cyan">
                <span className="text-cyan-400 font-bold font-sans text-xs">REQUIREX AI OUTPUT (IEEE 830 SPECIFICATION):</span>
                <p className="text-cyan-200 mt-2 text-xs font-sans font-semibold">"The system shall process ticket reservation requests within 1.2 seconds under a peak concurrency load of 50,000 active users."</p>
                <div className="mt-3 flex items-center space-x-2 text-[10px] text-emerald-400 font-sans">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>IEEE Standard Compliant • Test Cases Generated • RTM Linked</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Grid Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/10">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-white tracking-tight">Enterprise Requirements Suite</h2>
          <p className="mt-3 text-slate-400 max-w-2xl mx-auto text-sm">Everything software teams, business analysts, and project managers need to eliminate requirement defects before coding.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: Cpu,
              title: "AI Requirement Extraction",
              desc: "Upload PDFs, DOCX, TXT documents or interview transcripts. RequireX classifies requirements into Functional, Non-functional, Business, System, User, and Technical types."
            },
            {
              icon: ShieldCheck,
              title: "IEEE Quality Auditor",
              desc: "Detect ambiguous terms, missing actors, non-testable clauses, and weak conditions. Get instant confidence scores and IEEE-standard rewriter suggestions."
            },
            {
              icon: Sparkles,
              title: "Domain Knowledge Engine",
              desc: "Select project domain (Railway, Hospital, E-Commerce, Banking, Education, Food Delivery). Receive intelligent recommendations for missing security & architectural features."
            },
            {
              icon: GitBranch,
              title: "Agile Story & Use Case Generator",
              desc: "Automatically synthesize Agile User Stories (As a / I want / So that) with story points, acceptance criteria checklists, and full textual use cases."
            },
            {
              icon: FileCheck,
              title: "Comprehensive Test Suite",
              desc: "Generate Positive, Negative, Boundary, Security, and Performance test cases complete with Test IDs, inputs, expected outputs, and priority levels."
            },
            {
              icon: FileSpreadsheet,
              title: "One-Click IEEE SRS Export",
              desc: "Export complete, production-formatted Software Requirement Specifications in PDF, Word (.docx), Markdown (.md), and Plain Text (.txt)."
            }
          ].map((f, i) => {
            const Icon = f.icon;
            return (
              <div key={i} className="glass-card glass-card-hover p-6 rounded-2xl border border-white/10 relative group">
                <div className="h-10 w-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 mb-4 group-hover:scale-110 transition duration-300">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{f.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{f.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Interactive Workflow Section */}
      <section id="workflow" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/10">
        <div className="text-center mb-16">
          <span className="text-xs font-semibold text-cyan-400 uppercase tracking-widest">End-to-End Pipeline</span>
          <h2 className="text-3xl font-bold text-white mt-2">How RequireX Works</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { step: "01", title: "Upload & Input", desc: "Paste raw text or upload requirement documents & interview transcripts." },
            { step: "02", title: "AI Quality Audit", desc: "RequireX flags ambiguity, missing constraints, and rewrites into IEEE standard." },
            { step: "03", title: "Artifact Synthesis", desc: "Generates Agile user stories, textual use cases, test matrices, and RTM." },
            { step: "04", title: "Download SRS", desc: "Export professional IEEE SRS documents in PDF, DOCX, Markdown, and TXT." }
          ].map((s, idx) => (
            <div key={idx} className="bg-surface/50 p-6 rounded-2xl border border-white/10 relative">
              <span className="text-4xl font-extrabold text-cyan-500/20 font-mono block mb-3">{s.step}</span>
              <h4 className="text-base font-bold text-white mb-1">{s.title}</h4>
              <p className="text-xs text-slate-400 leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Tech Stack Showcase */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/10 text-center">
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-6">Engineered with Enterprise Standards</h3>
        <div className="flex flex-wrap items-center justify-center gap-6">
          {['IEEE Std 830-1998', 'ISO/IEC/IEEE 29148', 'React 18', 'TypeScript', 'Tailwind CSS', 'Framer Motion', 'jsPDF', 'DOCX Engine'].map((tech, i) => (
            <span key={i} className="px-4 py-2 rounded-xl bg-surface border border-white/10 text-xs font-mono text-cyan-300">
              {tech}
            </span>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 py-8 px-4 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <Boxes className="h-4 w-4 text-cyan-400" />
            <span className="font-bold text-white font-mono">RequireX AI Suite</span>
            <span>• Enterprise Requirements Engineering</span>
          </div>
          <p>© 2026 RequireX. Built for Software Engineers & Business Analysts.</p>
        </div>
      </footer>
    </div>
  );
};
