import React from 'react';
import { 
  Boxes, 
  Plus, 
  Search, 
  Sparkles, 
  History, 
  UserCheck, 
  ChevronDown, 
  FolderGit2
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';

export const Navbar: React.FC<{ onLandingClick: () => void; isLanding: boolean }> = ({ onLandingClick, isLanding }) => {
  const { 
    projects, 
    currentProject, 
    selectProject, 
    setIsCreateProjectOpen, 
    setIsAIChatOpen, 
    setIsGlobalSearchOpen,
    setIsHistoryOpen,
    userSession,
    setIsAuthModalOpen
  } = useProject();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#0B0B0F]/90 backdrop-blur-2xl">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 lg:px-8">
        
        {/* Brand & Project Selector */}
        <div className="flex items-center space-x-6">
          <button 
            onClick={onLandingClick}
            className="flex items-center space-x-3 group text-left focus:outline-none"
          >
            <div className="relative flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-500 via-blue-600 to-purple-600 p-[1.5px] shadow-neon-cyan">
              <div className="flex h-full w-full items-center justify-center rounded-[14px] bg-[#0B0B0F] transition duration-300 group-hover:bg-opacity-80">
                <Boxes className="h-6 w-6 text-cyan-400 group-hover:scale-110 transition duration-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-black tracking-tight text-white font-mono">Require<span className="text-cyan-400">X</span></span>
                <span className="rounded-full bg-cyan-500/10 px-2.5 py-0.5 text-[10px] font-extrabold text-cyan-400 border border-cyan-500/30">
                  AI SUITE v2.0
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block font-medium">IEEE Requirements Engineering</p>
            </div>
          </button>

          {!isLanding && (
            <div className="hidden md:flex items-center space-x-3 pl-6 border-l border-white/10">
              {/* Project Selector Dropdown */}
              <div className="relative">
                <select
                  value={currentProject?.id || ''}
                  onChange={(e) => selectProject(e.target.value)}
                  className="appearance-none bg-surface/90 hover:bg-surface border border-white/15 hover:border-cyan-500/50 text-slate-200 text-xs font-semibold rounded-xl px-4 py-2 pr-9 cursor-pointer focus:outline-none transition shadow-sm"
                >
                  {projects.map(p => (
                    <option key={p.id} value={p.id} className="bg-[#12121A] text-slate-200 py-1">
                      📂 {p.name} ({p.domain})
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-3 h-3.5 w-3.5 text-cyan-400 pointer-events-none" />
              </div>

              {/* Create New Project CTA */}
              <button
                onClick={() => setIsCreateProjectOpen(true)}
                className="flex items-center space-x-1.5 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 text-cyan-300 text-xs font-bold px-3.5 py-2 rounded-xl border border-cyan-500/40 transition shadow-neon-cyan"
              >
                <Plus className="h-4 w-4 text-cyan-400" />
                <span>New Project</span>
              </button>
            </div>
          )}
        </div>

        {/* Global Controls & Actions */}
        <div className="flex items-center space-x-4">
          {!isLanding && (
            <>
              {/* Global Search Button */}
              <button
                onClick={() => setIsGlobalSearchOpen(true)}
                className="hidden lg:flex items-center space-x-3 bg-surface/90 hover:bg-surface text-slate-400 hover:text-slate-200 text-xs px-4 py-2 rounded-xl border border-white/10 hover:border-cyan-500/30 transition shadow-sm"
              >
                <Search className="h-4 w-4 text-cyan-400" />
                <span className="font-medium">Search reqs, stories, tests...</span>
                <kbd className="bg-black/50 text-[10px] font-mono text-cyan-300 px-2 py-0.5 rounded border border-white/10">Ctrl+K</kbd>
              </button>

              {/* Version History Drawer Trigger */}
              <button
                onClick={() => setIsHistoryOpen(true)}
                className="p-2.5 text-slate-400 hover:text-cyan-400 bg-surface/60 hover:bg-surface rounded-xl border border-white/10 transition relative"
                title="Version Control Timeline"
              >
                <History className="h-4 w-4" />
                {currentProject?.history && currentProject.history.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
                )}
              </button>

              {/* AI Co-Pilot Drawer Trigger */}
              <button
                onClick={() => setIsAIChatOpen(true)}
                className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-neon-cyan transition duration-200"
              >
                <Sparkles className="h-4 w-4 text-cyan-200 animate-spin-slow" />
                <span className="hidden sm:inline">AI Co-Pilot</span>
              </button>
            </>
          )}

          {/* User Profile / Login */}
          {userSession.isLoggedIn ? (
            <div className="flex items-center space-x-2.5 bg-surface/90 px-3 py-1.5 rounded-xl border border-white/10">
              <div className="h-7 w-7 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 font-bold text-xs border border-cyan-500/40">
                {userSession.username.charAt(0)}
              </div>
              <div className="hidden xl:block text-left">
                <p className="text-xs font-bold text-slate-200 leading-none">{userSession.username}</p>
                <p className="text-[9px] text-slate-400 leading-tight mt-0.5">{userSession.role}</p>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="flex items-center space-x-1.5 bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs px-4 py-2 rounded-xl transition shadow-neon-cyan"
            >
              <UserCheck className="h-4 w-4" />
              <span>Sign In</span>
            </button>
          )}

          {isLanding && (
            <button
              onClick={onLandingClick}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs px-5 py-2.5 rounded-xl shadow-neon-cyan transition duration-200"
            >
              Launch RequireX Workspace →
            </button>
          )}
        </div>

      </div>
    </header>
  );
};
