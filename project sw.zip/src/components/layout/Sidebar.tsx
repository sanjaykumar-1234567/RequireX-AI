import React from 'react';
import { 
  LayoutDashboard, 
  FileUp, 
  ShieldCheck, 
  Sparkles, 
  BookOpenCheck, 
  GitMerge, 
  CheckSquare, 
  AlertTriangle, 
  Network, 
  FileSpreadsheet, 
  BarChart3,
  Award,
  Cpu,
  GitPullRequest
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, currentProject } = useProject();

  const reqCount = currentProject?.requirements.length || 0;
  const issuesCount = currentProject?.requirements.reduce((acc, r) => acc + r.issues.length, 0) || 0;
  const storiesCount = currentProject?.userStories.length || 0;
  const testsCount = currentProject?.testCases.length || 0;

  const menuSections = [
    {
      title: 'CORE DASHBOARD',
      items: [
        { id: 'dashboard', label: 'Dashboard Overview', icon: LayoutDashboard, badge: null },
        { id: 'analytics', label: 'Interactive Analytics', icon: BarChart3, badge: 'CHARTS', color: 'text-purple-400' },
      ]
    },
    {
      title: 'REQUIREMENTS SUITE',
      items: [
        { id: 'upload', label: 'Requirement Upload', icon: FileUp, badge: reqCount ? `${reqCount}` : null },
        { id: 'quality', label: 'IEEE Quality Audit', icon: ShieldCheck, badge: issuesCount ? `${issuesCount} flags` : null, color: issuesCount > 0 ? 'text-amber-400' : 'text-emerald-400' },
        { id: 'recommendations', label: 'Domain Suggestions', icon: Sparkles, badge: 'AI' },
      ]
    },
    {
      title: 'INNOVATIVE SE TOOLS',
      items: [
        { id: 'compliance', label: 'IEEE 29148 Radar', icon: Award, badge: 'IEEE' },
        { id: 'architecture', label: 'System Architecture DFD', icon: Cpu, badge: 'NEW' },
        { id: 'impact', label: 'Scope Creep Simulator', icon: GitPullRequest, badge: 'SIM' },
      ]
    },
    {
      title: 'ARTIFACTS & EXPORTS',
      items: [
        { id: 'user-stories', label: 'Agile User Stories', icon: BookOpenCheck, badge: storiesCount ? `${storiesCount}` : null },
        { id: 'use-cases', label: 'Textual Use Cases', icon: GitMerge, badge: null },
        { id: 'test-cases', label: 'Test Case Matrix', icon: CheckSquare, badge: testsCount ? `${testsCount}` : null },
        { id: 'risks', label: 'Risk Radar', icon: AlertTriangle, badge: currentProject?.risks.length ? `${currentProject.risks.length}` : null },
        { id: 'rtm', label: 'Traceability Matrix', icon: Network, badge: null },
        { id: 'srs', label: 'IEEE SRS Exporter', icon: FileSpreadsheet, badge: 'PDF' },
      ]
    }
  ];

  return (
    <aside className="w-72 flex-shrink-0 border-r border-white/10 bg-[#0B0B0F]/95 p-5 min-h-[calc(100vh-5rem)] hidden lg:block">
      
      {/* Active Context Card */}
      <div className="mb-6 px-4 py-3 rounded-2xl bg-surface/70 border border-white/10 shadow-sm">
        <p className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase font-mono">Active Project Context</p>
        <p className="text-xs font-black text-cyan-400 truncate mt-1 font-mono">{currentProject?.name || 'No Project Selected'}</p>
        <div className="flex items-center justify-between mt-2 text-[10px] text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            {currentProject?.domain || 'General'}
          </span>
          <span className="font-mono text-cyan-300">{reqCount} Reqs</span>
        </div>
      </div>

      {/* Navigation Sections */}
      <nav className="space-y-6">
        {menuSections.map((section, sIdx) => (
          <div key={sIdx} className="space-y-1.5">
            <p className="px-3 text-[10px] font-black text-slate-400 uppercase tracking-widest font-mono mb-2">
              {section.title}
            </p>
            {section.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition duration-200 group ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-500/20 via-blue-600/20 to-purple-600/10 text-cyan-300 border border-cyan-500/40 shadow-neon-cyan'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-surface/80 border border-transparent'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon className={`h-4 w-4 transition duration-200 ${isActive ? 'text-cyan-400 scale-110' : 'text-slate-400 group-hover:text-cyan-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className={`px-2 py-0.5 text-[9px] font-extrabold rounded-full border font-mono ${
                      isActive 
                        ? 'bg-cyan-500/30 text-cyan-200 border-cyan-500/40' 
                        : item.color 
                        ? `${item.color} bg-white/5 border-white/10` 
                        : 'bg-white/5 text-slate-400 border-white/10'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </nav>
    </aside>
  );
};
