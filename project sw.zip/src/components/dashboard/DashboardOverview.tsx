import React from 'react';
import { 
  FileUp, 
  ShieldAlert, 
  BookOpenCheck, 
  CheckSquare, 
  FileSpreadsheet, 
  Sparkles, 
  Plus, 
  TrendingUp, 
  Clock, 
  Download, 
  CheckCircle2, 
  AlertTriangle,
  FolderGit2
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { ExportService } from '../../services/exportService';

export const DashboardOverview: React.FC = () => {
  const { 
    currentProject, 
    projects, 
    selectProject, 
    setIsCreateProjectOpen, 
    setActiveTab 
  } = useProject();

  if (!currentProject) return null;

  const totalReqs = currentProject.requirements.length;
  const funcReqs = currentProject.requirements.filter(r => r.category === 'Functional').length;
  const nonFuncReqs = currentProject.requirements.filter(r => r.category !== 'Functional').length;
  const issuesCount = currentProject.requirements.reduce((acc, r) => acc + r.issues.length, 0);
  const storiesCount = currentProject.userStories.length;
  const testsCount = currentProject.testCases.length;
  const risksCount = currentProject.risks.length;

  const healthScore = totalReqs > 0 
    ? Math.max(0, Math.round(((totalReqs * 2 - issuesCount) / (totalReqs * 2)) * 100))
    : 100;

  const completionPercent = totalReqs > 0
    ? Math.min(100, Math.round(((totalReqs + storiesCount + testsCount) / (totalReqs * 3)) * 100))
    : 0;

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Actions */}
      <div className="glass-card p-6 rounded-2xl border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 blur-3xl pointer-events-none rounded-full" />
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-[10px] font-bold">
                DOMAIN: {currentProject.domain.toUpperCase()}
              </span>
              <span className="text-slate-400 text-xs">• Last updated: {currentProject.updatedAt}</span>
            </div>
            <h1 className="text-2xl font-extrabold text-white mt-1 font-mono">{currentProject.name}</h1>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">{currentProject.description}</p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveTab('upload')}
              className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs shadow-neon-cyan transition duration-200"
            >
              <FileUp className="h-4 w-4" />
              <span>Upload Requirement</span>
            </button>
            <button
              onClick={() => ExportService.exportPDF(currentProject)}
              className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-surface hover:bg-surface-hover text-slate-200 border border-white/10 text-xs font-semibold transition duration-200"
            >
              <Download className="h-4 w-4 text-cyan-400" />
              <span>Export SRS PDF</span>
            </button>
          </div>
        </div>
      </div>

      {/* Analytics KPI Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Requirements', value: totalReqs, sub: `${funcReqs} Functional | ${nonFuncReqs} Non-Func`, icon: FileUp, color: 'text-cyan-400' },
          { label: 'IEEE Quality Health', value: `${healthScore}%`, sub: `${issuesCount} Ambiguity Flag(s)`, icon: ShieldAlert, color: healthScore > 80 ? 'text-emerald-400' : 'text-amber-400' },
          { label: 'Generated Test Cases', value: testsCount, sub: 'Across 6 Quality Suites', icon: CheckSquare, color: 'text-blue-400' },
          { label: 'Project Completion', value: `${completionPercent}%`, sub: `${storiesCount} Agile User Stories`, icon: TrendingUp, color: 'text-purple-400' },
        ].map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <div key={idx} className="glass-card p-4 rounded-xl border border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-medium text-slate-400">{kpi.label}</span>
                <Icon className={`h-4 w-4 ${kpi.color}`} />
              </div>
              <p className={`text-2xl font-extrabold font-mono ${kpi.color}`}>{kpi.value}</p>
              <p className="text-[10px] text-slate-400 mt-1">{kpi.sub}</p>
            </div>
          );
        })}
      </div>

      {/* Main Grid: Recent Projects & AI Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Requirements Overview & Recent Projects */}
        <div className="lg:col-span-2 space-y-6">
          {/* Active Requirements Snapshot */}
          <div className="glass-card p-5 rounded-xl border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileUp className="h-4 w-4 text-cyan-400" />
                <span>Active Requirements Inventory</span>
              </h3>
              <button 
                onClick={() => setActiveTab('quality')}
                className="text-xs text-cyan-400 hover:underline"
              >
                Inspect Quality Audit →
              </button>
            </div>

            {currentProject.requirements.length === 0 ? (
              <div className="text-center py-8 border border-dashed border-white/10 rounded-xl">
                <p className="text-xs text-slate-400">No requirements loaded yet in this project.</p>
                <button
                  onClick={() => setActiveTab('upload')}
                  className="mt-3 px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 text-xs font-semibold border border-cyan-500/30"
                >
                  Upload Requirements Now
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {currentProject.requirements.slice(0, 4).map(req => (
                  <div key={req.id} className="p-3 rounded-lg bg-black/40 border border-white/5 flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-mono font-bold text-cyan-400">{req.id}</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/5 text-slate-300 border border-white/10">{req.category}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${req.priority === 'Critical' ? 'bg-red-500/20 text-red-400 border border-red-500/30' : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'}`}>{req.priority}</span>
                      </div>
                      <p className="text-xs text-slate-200 mt-1 font-medium">{req.improvedText || req.description}</p>
                    </div>

                    {req.issues.length > 0 ? (
                      <span className="flex-shrink-0 px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 text-[10px] border border-amber-500/30 flex items-center gap-1">
                        <AlertTriangle className="h-3 w-3" />
                        {req.issues.length} Flag
                      </span>
                    ) : (
                      <span className="flex-shrink-0 px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] border border-emerald-500/30 flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3" />
                        IEEE OK
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Projects Switcher */}
          <div className="glass-card p-5 rounded-xl border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FolderGit2 className="h-4 w-4 text-purple-400" />
                <span>Recent Workspace Projects</span>
              </h3>
              <button
                onClick={() => setIsCreateProjectOpen(true)}
                className="flex items-center space-x-1 text-xs text-cyan-400 hover:underline"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Create Project</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {projects.map(p => (
                <div
                  key={p.id}
                  onClick={() => selectProject(p.id)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition duration-200 ${
                    p.id === currentProject.id
                      ? 'bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/40 shadow-neon-cyan'
                      : 'bg-surface/60 hover:bg-surface border-white/5 hover:border-white/20'
                  }`}
                >
                  <p className="text-xs font-bold text-white font-mono truncate">{p.name}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{p.domain} • {p.requirements.length} Reqs</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: AI Activity Feed & Quick Export Shortcuts */}
        <div className="space-y-6">
          
          {/* AI Activity Feed */}
          <div className="glass-card p-5 rounded-xl border border-white/10">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4">
              <Sparkles className="h-4 w-4 text-cyan-400" />
              <span>RequireX AI Activity Log</span>
            </h3>

            <div className="space-y-3 relative pl-3 border-l border-white/10 text-xs">
              {[
                { time: 'Just now', title: 'IEEE Quality Audit Executed', desc: `${issuesCount} quality issues identified with confidence ratings.` },
                { time: '2m ago', title: 'Agile User Stories Synthesized', desc: `${storiesCount} user stories generated with story points & acceptance criteria.` },
                { time: '5m ago', title: 'Automated Test Suite Compiled', desc: `${testsCount} positive, negative, security, and boundary test cases.` },
                { time: '10m ago', title: 'RTM Matrix Synchronized', desc: 'Requirements to Test Cases mapping updated.' },
              ].map((act, i) => (
                <div key={i} className="relative">
                  <div className="absolute -left-[17px] top-1 h-2 w-2 rounded-full bg-cyan-400 ring-4 ring-[#0B0B0F]" />
                  <p className="text-[10px] text-slate-400">{act.time}</p>
                  <p className="font-semibold text-slate-200 mt-0.5">{act.title}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">{act.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Exports Card */}
          <div className="glass-card p-5 rounded-xl border border-white/10">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-3">
              <FileSpreadsheet className="h-4 w-4 text-emerald-400" />
              <span>Quick SRS Document Exports</span>
            </h3>
            <p className="text-xs text-slate-400 mb-3">Download complete IEEE Std 830 / 29148 Software Requirement Specification:</p>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => ExportService.exportPDF(currentProject)}
                className="p-2 rounded-lg bg-surface hover:bg-surface-hover border border-white/10 text-xs text-slate-200 flex items-center justify-center gap-1.5 transition"
              >
                <Download className="h-3.5 w-3.5 text-red-400" />
                <span>PDF Document</span>
              </button>
              <button
                onClick={() => ExportService.exportDOCX(currentProject)}
                className="p-2 rounded-lg bg-surface hover:bg-surface-hover border border-white/10 text-xs text-slate-200 flex items-center justify-center gap-1.5 transition"
              >
                <Download className="h-3.5 w-3.5 text-blue-400" />
                <span>Word (.docx)</span>
              </button>
              <button
                onClick={() => ExportService.exportMarkdown(currentProject)}
                className="p-2 rounded-lg bg-surface hover:bg-surface-hover border border-white/10 text-xs text-slate-200 flex items-center justify-center gap-1.5 transition"
              >
                <Download className="h-3.5 w-3.5 text-cyan-400" />
                <span>Markdown (.md)</span>
              </button>
              <button
                onClick={() => ExportService.exportText(currentProject)}
                className="p-2 rounded-lg bg-surface hover:bg-surface-hover border border-white/10 text-xs text-slate-200 flex items-center justify-center gap-1.5 transition"
              >
                <Download className="h-3.5 w-3.5 text-slate-400" />
                <span>Plain Text (.txt)</span>
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
