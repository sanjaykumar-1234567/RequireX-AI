import React, { useState } from 'react';
import { 
  FileUp, 
  Sparkles, 
  Upload, 
  FileText, 
  Layers, 
  Trash2, 
  Edit3, 
  CheckCircle, 
  FileCheck,
  AlertCircle
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { AIEngine } from '../../services/aiEngine';
import { RequirementCategory } from '../../types';

export const ModuleUpload: React.FC = () => {
  const { currentProject, addRequirementsToProject } = useProject();
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState<'paste' | 'upload' | 'transcript'>('paste');

  const handleExtract = () => {
    if (!inputText.trim() || !currentProject) return;
    setIsProcessing(true);

    setTimeout(() => {
      const extracted = AIEngine.extractRequirements(inputText, currentProject.domain);
      addRequirementsToProject(extracted);
      setIsProcessing(false);
      setInputText('');
    }, 800);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentProject) return;

    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setTimeout(() => {
        const extracted = AIEngine.extractRequirements(text || file.name, currentProject.domain);
        addRequirementsToProject(extracted);
        setIsProcessing(false);
      }, 1000);
    };
    reader.readAsText(file);
  };

  const loadSampleTranscript = () => {
    setInputText(
      `Stakeholder Interview Transcript - ${currentProject?.domain || 'Software System'}
Stakeholder: "The system should allow users to book tickets fast. We also need to encrypt patient/payment data with high security standards. The admin dashboard must display real-time transaction logs and generate PDF reports. The app should load within 2 seconds even during peak load."`
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="glass-card p-6 rounded-2xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold mb-1">
            <FileUp className="h-4 w-4" />
            <span>MODULE 1 & 2 • REQUIREMENT INGESTION & CLASSIFICATION</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white font-mono">Upload & Extract Requirements</h1>
          <p className="text-xs text-slate-300 mt-1">
            Upload PDF, DOCX, TXT documents or stakeholder interview transcripts. RequireX AI automatically classifies requirements into Functional, Non-functional, System, Business, User, and Technical categories.
          </p>
        </div>
      </div>

      {/* Input Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Parser Dropzone / Manual Textarea */}
        <div className="lg:col-span-2 glass-card p-6 rounded-2xl border border-white/10 space-y-4">
          
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setActiveTab('paste')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${activeTab === 'paste' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'}`}
              >
                Paste Requirement Text
              </button>
              <button
                onClick={() => setActiveTab('upload')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${activeTab === 'upload' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'}`}
              >
                Upload File (PDF / DOCX / TXT)
              </button>
              <button
                onClick={() => setActiveTab('transcript')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${activeTab === 'transcript' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'}`}
              >
                Interview Transcripts
              </button>
            </div>

            <button
              onClick={loadSampleTranscript}
              className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1"
            >
              <Sparkles className="h-3 w-3" />
              <span>Load Sample Data</span>
            </button>
          </div>

          {activeTab === 'upload' ? (
            <div className="border-2 border-dashed border-white/15 hover:border-cyan-500/50 rounded-2xl p-10 text-center transition cursor-pointer bg-black/40 group">
              <input
                type="file"
                accept=".pdf,.docx,.txt"
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload-input"
              />
              <label htmlFor="file-upload-input" className="cursor-pointer">
                <Upload className="h-10 w-10 text-cyan-400 mx-auto mb-3 group-hover:scale-110 transition" />
                <p className="text-sm font-bold text-white">Click or drag & drop requirement document</p>
                <p className="text-xs text-slate-400 mt-1">Supports PDF, Word (.docx), Plain Text (.txt), and Transcripts</p>
              </label>
            </div>
          ) : (
            <div>
              <textarea
                rows={6}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Enter client requirements or stakeholder interview text here (one requirement per line or bullet)..."
                className="w-full bg-black/50 border border-white/10 rounded-xl p-4 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono leading-relaxed"
              />
              <div className="flex items-center justify-between mt-3">
                <span className="text-[11px] text-slate-400">
                  Target Domain: <span className="text-cyan-400 font-semibold">{currentProject?.domain}</span>
                </span>
                <button
                  onClick={handleExtract}
                  disabled={isProcessing || !inputText.trim()}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 text-black font-bold text-xs shadow-neon-cyan transition flex items-center space-x-2"
                >
                  <Sparkles className={`h-4 w-4 ${isProcessing ? 'animate-spin' : ''}`} />
                  <span>{isProcessing ? 'AI Extracting Requirements...' : 'Execute AI Extraction'}</span>
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Right Col: Category Breakdown Stats */}
        <div className="glass-card p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Layers className="h-4 w-4 text-cyan-400" />
            <span>Extracted Classification Breakdown</span>
          </h3>

          <div className="space-y-3">
            {[
              { cat: 'Functional', desc: 'Core software behaviors & user actions' },
              { cat: 'Non-functional', desc: 'Performance, security, availability SLAs' },
              { cat: 'System', desc: 'Admin tools, system architecture, background jobs' },
              { cat: 'Technical', desc: 'APIs, database integrations, protocols' },
              { cat: 'Business', desc: 'Compliance, revenue rules, policies' },
              { cat: 'User', desc: 'User persona roles & UI capabilities' },
            ].map((item, idx) => {
              const count = currentProject?.requirements.filter(r => r.category === item.cat).length || 0;
              return (
                <div key={idx} className="p-2.5 rounded-lg bg-surface/80 border border-white/5 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-slate-200">{item.cat}</p>
                    <p className="text-[10px] text-slate-400">{item.desc}</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-mono font-bold border border-cyan-500/30">
                    {count}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* Extracted Requirement Cards Display */}
      <div className="glass-card p-6 rounded-2xl border border-white/10">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2 font-mono">
            <FileCheck className="h-4 w-4 text-emerald-400" />
            <span>Extracted Requirement Inventory ({currentProject?.requirements.length || 0})</span>
          </h3>
        </div>

        {currentProject?.requirements.length === 0 ? (
          <p className="text-xs text-slate-400 text-center py-8">No requirements in inventory. Paste text above to extract.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentProject?.requirements.map(req => (
              <div key={req.id} className="p-4 rounded-xl bg-black/40 border border-white/10 hover:border-cyan-500/40 transition">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono font-bold text-cyan-400">{req.id}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/5 text-slate-300 border border-white/10">{req.category}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${req.priority === 'Critical' ? 'bg-red-500/20 text-red-400' : 'bg-blue-500/20 text-blue-400'}`}>
                    {req.priority}
                  </span>
                </div>

                <p className="text-xs text-slate-200 font-medium leading-relaxed">{req.improvedText || req.description}</p>

                {req.issues.length > 0 && (
                  <div className="mt-3 p-2 rounded bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300 flex items-center justify-between">
                    <span>⚠️ {req.issues.length} IEEE Quality Issue(s) detected</span>
                    <span className="text-[10px] font-mono text-amber-400">{req.issues[0].severity} Severity</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
