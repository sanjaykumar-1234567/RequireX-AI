import React, { useState } from 'react';
import { 
  BarChart3, 
  PieChart, 
  TrendingUp, 
  ShieldAlert, 
  FileCheck, 
  CheckSquare, 
  BookOpenCheck,
  Zap,
  Activity,
  Layers,
  AlertTriangle,
  Award
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';

export const ModuleAnalytics: React.FC = () => {
  const { currentProject } = useProject();
  const [activeChartTab, setActiveChartTab] = useState<'categories' | 'velocity' | 'risks' | 'quality'>('categories');

  if (!currentProject) return null;

  const totalReqs = currentProject.requirements.length;
  const funcReqs = currentProject.requirements.filter(r => r.category === 'Functional').length;
  const nonFuncReqs = currentProject.requirements.filter(r => r.category !== 'Functional').length;
  const ambiguousReqs = currentProject.requirements.filter(r => r.issues.some(i => i.type === 'Ambiguous word')).length;
  const storiesCount = currentProject.userStories.length;
  const testsCount = currentProject.testCases.length;
  const totalPoints = currentProject.userStories.reduce((acc, s) => acc + s.storyPoints, 0);

  const completionPercent = totalReqs > 0
    ? Math.min(100, Math.round(((totalReqs + storiesCount + testsCount) / (totalReqs * 3)) * 100))
    : 0;

  const categories = ['Functional', 'Non-functional', 'Business', 'System', 'User', 'Technical'] as const;
  const categoryCounts = categories.map(cat => ({
    name: cat,
    count: currentProject.requirements.filter(r => r.category === cat).length
  }));

  const testCategoryCounts = ['Positive', 'Negative', 'Boundary', 'Security', 'Performance'].map(cat => ({
    name: cat,
    count: currentProject.testCases.filter(t => t.category === cat).length
  }));

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="glass-card p-6 rounded-2xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-purple-400 text-xs font-bold mb-1">
            <BarChart3 className="h-4 w-4" />
            <span>INTERACTIVE ANALYTICS & VISUAL METRIC DASHBOARD</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white font-mono">Software Engineering Intelligence</h1>
          <p className="text-xs text-slate-300 mt-1">
            Visual graphs, quality indices, story point velocity distributions, test coverage meters, and risk heatmaps.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-surface/80 p-1.5 rounded-xl border border-white/10">
          <button
            onClick={() => setActiveChartTab('categories')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${activeChartTab === 'categories' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Categories
          </button>
          <button
            onClick={() => setActiveChartTab('velocity')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${activeChartTab === 'velocity' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Story Velocity
          </button>
          <button
            onClick={() => setActiveChartTab('risks')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${activeChartTab === 'risks' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Risk Heatmap
          </button>
        </div>
      </div>

      {/* Top Visual Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-card p-5 rounded-2xl border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold text-slate-400">REQUIREMENTS INVENTORY</span>
            <FileCheck className="h-5 w-5 text-cyan-400" />
          </div>
          <p className="text-3xl font-extrabold font-mono text-cyan-400">{totalReqs}</p>
          <p className="text-[10px] text-slate-400 mt-1">{funcReqs} Functional | {nonFuncReqs} Non-Func</p>
        </div>

        <div className="glass-card p-5 rounded-2xl border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold text-slate-400">AGILE STORY POINTS</span>
            <BookOpenCheck className="h-5 w-5 text-purple-400" />
          </div>
          <p className="text-3xl font-extrabold font-mono text-purple-400">{totalPoints} pts</p>
          <p className="text-[10px] text-slate-400 mt-1">{storiesCount} Agile User Stories</p>
        </div>

        <div className="glass-card p-5 rounded-2xl border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold text-slate-400">QA TEST SUITES</span>
            <CheckSquare className="h-5 w-5 text-emerald-400" />
          </div>
          <p className="text-3xl font-extrabold font-mono text-emerald-400">{testsCount}</p>
          <p className="text-[10px] text-slate-400 mt-1">Across 6 Quality Suites</p>
        </div>

        <div className="glass-card p-5 rounded-2xl border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold text-slate-400">IEEE QUALITY SCORE</span>
            <ShieldAlert className="h-5 w-5 text-amber-400" />
          </div>
          <p className="text-3xl font-extrabold font-mono text-amber-400">
            {totalReqs > 0 ? Math.round(((totalReqs - ambiguousReqs) / totalReqs) * 100) : 100}%
          </p>
          <p className="text-[10px] text-slate-400 mt-1">{ambiguousReqs} Ambiguity Flag(s)</p>
        </div>
      </div>

      {/* Interactive Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Chart 1: Visual Bar Distribution */}
        <div className="glass-card p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-cyan-400" />
            <span>Requirement Distribution Graph</span>
          </h3>

          <div className="space-y-3 pt-2">
            {categoryCounts.map((item, idx) => {
              const pct = totalReqs > 0 ? Math.round((item.count / totalReqs) * 100) : 0;
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-200 font-semibold">{item.name}</span>
                    <span className="text-cyan-400 font-bold">{item.count} items ({pct}%)</span>
                  </div>
                  <div className="w-full h-3 rounded-full bg-black/60 overflow-hidden border border-white/10 p-0.5">
                    <div 
                      className="h-full bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 rounded-full transition-all duration-500" 
                      style={{ width: `${Math.max(pct, 5)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 2: Test Case Coverage Breakdown */}
        <div className="glass-card p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <Activity className="h-4 w-4 text-emerald-400" />
            <span>QA Test Suite Distribution Graph</span>
          </h3>

          <div className="space-y-3 pt-2">
            {testCategoryCounts.map((item, idx) => {
              const maxTests = Math.max(testsCount, 1);
              const pct = Math.round((item.count / maxTests) * 100);
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-200 font-semibold">{item.name} Suite</span>
                    <span className="text-emerald-400 font-bold">{item.count} test cases</span>
                  </div>
                  <div className="w-full h-3 rounded-full bg-black/60 overflow-hidden border border-white/10 p-0.5">
                    <div 
                      className="h-full bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-400 rounded-full transition-all duration-500" 
                      style={{ width: `${Math.max(pct, 8)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* Progress Donut & Radial Lifecycle Gauges */}
      <div className="glass-card p-6 rounded-2xl border border-white/10 space-y-4">
        <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-purple-400" />
          <span>Overall Software Engineering Progress ({completionPercent}%)</span>
        </h3>

        <div className="w-full h-4 rounded-full bg-black/60 overflow-hidden border border-white/10 p-0.5">
          <div 
            className="h-full bg-gradient-to-r from-cyan-500 via-purple-500 to-emerald-400 rounded-full transition-all duration-500 shadow-neon-cyan"
            style={{ width: `${completionPercent}%` }}
          />
        </div>
      </div>

    </div>
  );
};
