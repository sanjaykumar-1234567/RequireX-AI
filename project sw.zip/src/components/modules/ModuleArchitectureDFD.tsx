import React from 'react';
import { Cpu, Server, Database, Globe, Lock, ArrowRight, Layers, ShieldCheck } from 'lucide-react';
import { useProject } from '../../context/ProjectContext';

export const ModuleArchitectureDFD: React.FC = () => {
  const { currentProject } = useProject();

  if (!currentProject) return null;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="glass-card p-6 rounded-2xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold mb-1">
            <Cpu className="h-4 w-4" />
            <span>INNOVATIVE MODULE • AUTOMATED ARCHITECTURE & DATA FLOW DIAGRAM (DFD)</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white font-mono">System Architecture & Data Flow Diagram</h1>
          <p className="text-xs text-slate-300 mt-1">
            Automatically generated Level-1 Data Flow Diagram (DFD) mapping user actors, client applications, API gateways, core processing kernels, and database layers for **{currentProject.name}**.
          </p>
        </div>
      </div>

      {/* Visual Architectural Data Flow Nodes */}
      <div className="glass-card p-8 rounded-2xl border border-white/10 space-y-8">
        <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
          <Layers className="h-4 w-4 text-cyan-400" />
          <span>Level-1 Software System Data Flow Architecture ({currentProject.domain})</span>
        </h3>

        {/* Node Flow Horizontal Pipeline */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
          
          {/* Node 1: Client UI */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-cyan-950/60 to-surface border border-cyan-500/30 text-center space-y-2 shadow-neon-cyan relative">
            <Globe className="h-8 w-8 text-cyan-400 mx-auto" />
            <h4 className="text-xs font-bold text-white font-mono">1.0 Client Interface</h4>
            <p className="text-[11px] text-slate-300">Web Dashboard & Mobile Client (React / TypeScript)</p>
            <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 text-[10px] font-mono block">REST / WebSockets</span>
          </div>

          {/* Node 2: API Gateway */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-blue-950/60 to-surface border border-blue-500/30 text-center space-y-2 relative">
            <Lock className="h-8 w-8 text-blue-400 mx-auto" />
            <h4 className="text-xs font-bold text-white font-mono">2.0 API Gateway & WAF</h4>
            <p className="text-[11px] text-slate-300">Rate Limiting, MFA Auth & Input Validation</p>
            <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px] font-mono block">JWT Auth Guard</span>
          </div>

          {/* Node 3: Core Processing Kernel */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-purple-950/60 to-surface border border-purple-500/30 text-center space-y-2 relative">
            <Cpu className="h-8 w-8 text-purple-400 mx-auto" />
            <h4 className="text-xs font-bold text-white font-mono">3.0 RequireX Kernel Engine</h4>
            <p className="text-[11px] text-slate-300">Domain Logic, IEEE Auditor & Story Synthesizer</p>
            <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[10px] font-mono block">AI Core Engine</span>
          </div>

          {/* Node 4: Persistence Layer */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-950/60 to-surface border border-emerald-500/30 text-center space-y-2 relative">
            <Database className="h-8 w-8 text-emerald-400 mx-auto" />
            <h4 className="text-xs font-bold text-white font-mono">4.0 Persistence & Audit Store</h4>
            <p className="text-[11px] text-slate-300">RTM Index, Test Matrix & Audit Logs</p>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono block">AES-256 Storage</span>
          </div>

        </div>

        {/* Data Stream Contracts */}
        <div className="bg-black/50 p-5 rounded-xl border border-white/10 font-mono text-xs text-slate-300 space-y-2">
          <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider block">System Component Contracts</span>
          <p>• Data Stream D1: Raw client payloads $\rightarrow$ API Gateway (HTTPS TLS 1.3)</p>
          <p>• Data Stream D2: Sanitized specifications $\rightarrow$ RequireX IEEE Kernel Engine</p>
          <p>• Data Stream D3: IEEE SRS artifacts, Agile Stories & Test Matrices $\rightarrow$ Database Persistence</p>
        </div>
      </div>
    </div>
  );
};
