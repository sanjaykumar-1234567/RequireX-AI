import React, { useState } from 'react';
import { GitPullRequest, AlertTriangle, CheckSquare, BookOpenCheck, GitMerge, RefreshCw } from 'lucide-react';
import { useProject } from '../../context/ProjectContext';

export const ModuleScopeImpact: React.FC = () => {
  const { currentProject } = useProject();
  const [selectedReqId, setSelectedReqId] = useState<string>(() => currentProject?.requirements[0]?.id || '');

  if (!currentProject) return null;

  const targetReq = currentProject.requirements.find(r => r.id === selectedReqId) || currentProject.requirements[0];

  const impactedStories = currentProject.userStories.filter(us => us.requirementId === selectedReqId);
  const impactedUseCases = currentProject.useCases.filter(uc => uc.requirementId === selectedReqId);
  const impactedTestCases = currentProject.testCases.filter(tc => tc.requirementId === selectedReqId);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="glass-card p-6 rounded-2xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold mb-1">
            <GitPullRequest className="h-4 w-4" />
            <span>INNOVATIVE MODULE • REQUIREMENT SCOPE CREEP & IMPACT SIMULATOR</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white font-mono">Scope Creep & Impact Analysis Simulator</h1>
          <p className="text-xs text-slate-300 mt-1">
            Simulate requirement modifications or scope changes to analyze downstream impacts on User Stories, Textual Use Cases, QA Test Suites, and System Risk Scores.
          </p>
        </div>
      </div>

      {/* Simulator Selector & Results */}
      <div className="glass-card p-6 rounded-2xl border border-white/10 space-y-6">
        
        {/* Requirement Dropdown Selector */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Select Target Requirement to Modify/Simulate:</label>
            <select
              value={selectedReqId}
              onChange={e => setSelectedReqId(e.target.value)}
              className="bg-black/60 border border-cyan-500/40 text-cyan-300 font-mono text-xs rounded-xl px-4 py-2 cursor-pointer focus:outline-none"
            >
              {currentProject.requirements.map(req => (
                <option key={req.id} value={req.id} className="bg-[#12121A] text-white">
                  [{req.id}] {req.title}
                </option>
              ))}
            </select>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono">
            ⚠️ SIMULATION MODE: CHANGE IMPACT RATING: HIGH
          </div>
        </div>

        {/* Selected Req Overview */}
        {targetReq && (
          <div className="bg-black/50 p-4 rounded-xl border border-white/10 space-y-2 text-xs">
            <div className="flex items-center space-x-2">
              <span className="font-mono font-bold text-cyan-400">{targetReq.id}</span>
              <span className="px-2 py-0.5 rounded bg-white/5 text-slate-300 border border-white/10">{targetReq.category}</span>
              <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-400 font-bold">{targetReq.priority} Priority</span>
            </div>
            <p className="text-slate-200 font-medium">{targetReq.improvedText || targetReq.description}</p>
          </div>
        )}

        {/* Downstream Impact Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* User Stories Impact */}
          <div className="bg-surface/60 p-4 rounded-xl border border-white/10 space-y-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-xs font-bold text-purple-400 flex items-center gap-1.5">
                <BookOpenCheck className="h-4 w-4" />
                Impacted Agile User Stories
              </span>
              <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono text-[10px] font-bold">
                {impactedStories.length} Stories
              </span>
            </div>

            <div className="space-y-2">
              {impactedStories.map(s => (
                <div key={s.id} className="p-2.5 rounded bg-black/40 border border-purple-500/20 text-xs text-slate-300">
                  <span className="font-mono font-bold text-purple-400">{s.id}: </span>
                  <span>As a {s.asA}, I want to {s.iWantTo}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Use Cases Impact */}
          <div className="bg-surface/60 p-4 rounded-xl border border-white/10 space-y-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                <GitMerge className="h-4 w-4" />
                Impacted Use Cases
              </span>
              <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono text-[10px] font-bold">
                {impactedUseCases.length} Use Cases
              </span>
            </div>

            <div className="space-y-2">
              {impactedUseCases.map(u => (
                <div key={u.id} className="p-2.5 rounded bg-black/40 border border-cyan-500/20 text-xs text-slate-300 font-mono">
                  <span className="font-bold text-cyan-400">{u.id}: </span>
                  <span>{u.title}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Test Cases Impact */}
          <div className="bg-surface/60 p-4 rounded-xl border border-white/10 space-y-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                <CheckSquare className="h-4 w-4" />
                Impacted QA Test Suites
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold">
                {impactedTestCases.length} Tests
              </span>
            </div>

            <div className="space-y-2">
              {impactedTestCases.map(t => (
                <div key={t.id} className="p-2.5 rounded bg-black/40 border border-emerald-500/20 text-xs text-slate-300 font-mono">
                  <span className="font-bold text-emerald-400">{t.id} ({t.category}): </span>
                  <span className="truncate block mt-0.5">{t.description}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
